/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunktrudesk"] = self["webpackChunktrudesk"] || []).push([[3],{

/***/ 1170:
/*!************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-clipboard/theme/clipboard.css ***!
  \************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-editor__editable {\\n| \\t/*\\n| \\t * Vertical drop target (in text).\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-clipboard/theme/clipboard.css?");

/***/ }),

/***/ 1141:
/*!***********************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-engine/theme/placeholder.css ***!
  \***********************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (7:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n| \\n| /* See ckeditor/ckeditor5#936. */\\n> .ck.ck-placeholder,\\n| .ck .ck-placeholder {\\n| \\tposition: relative;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-engine/theme/placeholder.css?");

/***/ }),

/***/ 1049:
/*!********************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-engine/theme/renderer.css ***!
  \********************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (7:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n| \\n| /* Elements marked by the Renderer as hidden should be invisible in the editor. */\\n> .ck.ck-editor__editable span[data-ck-unsafe-element] {\\n| \\tdisplay: none;\\n| }\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-engine/theme/renderer.css?");

/***/ }),

/***/ 1606:
/*!****************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-image/theme/image.css ***!
  \****************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck-content {\\n| \\t& .image {\\n| \\t\\tdisplay: table;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-image/theme/image.css?");

/***/ }),

/***/ 1665:
/*!***********************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-image/theme/imagecaption.css ***!
  \***********************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> :root {\\n| \\t--ck-color-image-caption-background: hsl(0, 0%, 97%);\\n| \\t--ck-color-image-caption-text: hsl(0, 0%, 20%);\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-image/theme/imagecaption.css?");

/***/ }),

/***/ 1670:
/*!*********************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-image/theme/imagestyle.css ***!
  \*********************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> :root {\\n| \\t--ck-image-style-spacing: 1.5em;\\n| \\t--ck-inline-image-style-spacing: calc(var(--ck-image-style-spacing) / 2);\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-image/theme/imagestyle.css?");

/***/ }),

/***/ 1677:
/*!**************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-image/theme/imageuploadicon.css ***!
  \**************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck-image-upload-complete-icon {\\n| \\tdisplay: block;\\n| \\tposition: absolute;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-image/theme/imageuploadicon.css?");

/***/ }),

/***/ 1678:
/*!****************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-image/theme/imageuploadloader.css ***!
  \****************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck .ck-upload-placeholder-loader {\\n| \\tposition: absolute;\\n| \\tdisplay: flex;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-image/theme/imageuploadloader.css?");

/***/ }),

/***/ 1676:
/*!******************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-image/theme/imageuploadprogress.css ***!
  \******************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-editor__editable {\\n| \\t& .image,\\n| \\t& .image-inline {\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-image/theme/imageuploadprogress.css?");

/***/ }),

/***/ 1655:
/*!******************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-image/theme/textalternativeform.css ***!
  \******************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected character '@' (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> @import \\\"@ckeditor/ckeditor5-ui/theme/mixins/_rwd.css\\\";\\n| \\n| .ck.ck-text-alternative-form {\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-image/theme/textalternativeform.css?");

/***/ }),

/***/ 1112:
/*!********************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/button/button.css ***!
  \********************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected character '@' (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> @import \\\"../../mixins/_unselectable.css\\\";\\n| \\n| .ck.ck-button,\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/button/button.css?");

/***/ }),

/***/ 1113:
/*!**************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/button/switchbutton.css ***!
  \**************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-button.ck-switchbutton {\\n| \\t& .ck-button__toggle {\\n| \\t\\tdisplay: block;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/button/switchbutton.css?");

/***/ }),

/***/ 1115:
/*!**************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/colorgrid/colorgrid.css ***!
  \**************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-color-grid {\\n| \\tdisplay: grid;\\n| }\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/colorgrid/colorgrid.css?");

/***/ }),

/***/ 1119:
/*!************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/dropdown/dropdown.css ***!
  \************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> :root {\\n| \\t--ck-dropdown-max-width: 75vw;\\n| }\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/dropdown/dropdown.css?");

/***/ }),

/***/ 1126:
/*!****************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/dropdown/listdropdown.css ***!
  \****************************************************************************************/
/***/ (() => {

eval("/*\n * Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.\n * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license\n */\n\n/*\n * Note: This file should contain the wireframe styles only. But since there are no such styles,\n * it acts as a message to the builder telling that it should look for the corresponding styles\n * **in the theme** when compiling the editor.\n */\n\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/dropdown/listdropdown.css?");

/***/ }),

/***/ 1116:
/*!***************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/dropdown/splitbutton.css ***!
  \***************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-splitbutton {\\n| \\t/* Enable font size inheritance, which allows fluid UI scaling. */\\n| \\tfont-size: inherit;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/dropdown/splitbutton.css?");

/***/ }),

/***/ 1125:
/*!*******************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/dropdown/toolbardropdown.css ***!
  \*******************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> :root {\\n| \\t--ck-toolbar-dropdown-max-width: 60vw;\\n| }\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/dropdown/toolbardropdown.css?");

/***/ }),

/***/ 1127:
/*!************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/editorui/editorui.css ***!
  \************************************************************************************/
/***/ (() => {

eval("/*\n * Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.\n * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license\n */\n\n/*\n * Note: This file should contain the wireframe styles only. But since there are no such styles,\n * it acts as a message to the builder telling that it should look for the corresponding styles\n * **in the theme** when compiling the editor.\n */\n\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/editorui/editorui.css?");

/***/ }),

/***/ 1130:
/*!****************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/formheader/formheader.css ***!
  \****************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-form__header {\\n| \\tdisplay: flex;\\n| \\tflex-direction: row;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/formheader/formheader.css?");

/***/ }),

/***/ 1111:
/*!****************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/icon/icon.css ***!
  \****************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-icon {\\n| \\tvertical-align: middle;\\n| }\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/icon/icon.css?");

/***/ }),

/***/ 1131:
/*!******************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/input/input.css ***!
  \******************************************************************************/
/***/ (() => {

eval("/*\n * Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.\n * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license\n */\n\n/*\n * Note: This file should contain the wireframe styles only. But since there are no such styles,\n * it acts as a message to the builder telling that it should look for the corresponding styles\n * **in the theme** when compiling the editor.\n */\n\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/input/input.css?");

/***/ }),

/***/ 1128:
/*!******************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/label/label.css ***!
  \******************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-label {\\n| \\tdisplay: block;\\n| }\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/label/label.css?");

/***/ }),

/***/ 1132:
/*!************************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/labeledfield/labeledfieldview.css ***!
  \************************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-labeled-field-view {\\n| \\t& > .ck.ck-labeled-field-view__input-wrapper {\\n| \\t\\tdisplay: flex;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/labeledfield/labeledfieldview.css?");

/***/ }),

/***/ 1123:
/*!****************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/list/list.css ***!
  \****************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected character '@' (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> @import \\\"../../mixins/_unselectable.css\\\";\\n| \\n| .ck.ck-list {\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/list/list.css?");

/***/ }),

/***/ 1081:
/*!*************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/panel/balloonpanel.css ***!
  \*************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> :root {\\n| \\t/* Make sure the balloon arrow does not float over its children. */\\n| \\t--ck-balloon-panel-arrow-z-index: calc(var(--ck-z-default) - 3);\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/panel/balloonpanel.css?");

/***/ }),

/***/ 1135:
/*!***************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/panel/balloonrotator.css ***!
  \***************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck .ck-balloon-rotator__navigation {\\n| \\tdisplay: flex;\\n| \\talign-items: center;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/panel/balloonrotator.css?");

/***/ }),

/***/ 1136:
/*!**********************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/panel/fakepanel.css ***!
  \**********************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck .ck-fake-panel {\\n| \\tposition: absolute;\\n| \");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/panel/fakepanel.css?");

/***/ }),

/***/ 1137:
/*!************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/panel/stickypanel.css ***!
  \************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-sticky-panel {\\n| \\t& .ck-sticky-panel__content_sticky {\\n| \\t\\tz-index: var(--ck-z-modal); /* #315 */\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/panel/stickypanel.css?");

/***/ }),

/***/ 1143:
/*!*************************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/responsive-form/responsiveform.css ***!
  \*************************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected character '@' (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> @import \\\"@ckeditor/ckeditor5-ui/theme/mixins/_rwd.css\\\";\\n| \\n| .ck-vertical-form .ck-button {\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/responsive-form/responsiveform.css?");

/***/ }),

/***/ 1139:
/*!***************************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/toolbar/blocktoolbar.css ***!
  \***************************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-block-toolbar-button {\\n| \\tposition: absolute;\\n| \\tz-index: var(--ck-z-default);\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/toolbar/blocktoolbar.css?");

/***/ }),

/***/ 1122:
/*!**********************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/toolbar/toolbar.css ***!
  \**********************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected character '@' (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> @import \\\"../../mixins/_unselectable.css\\\";\\n| \\n| .ck.ck-toolbar {\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/toolbar/toolbar.css?");

/***/ }),

/***/ 1082:
/*!**********************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/components/tooltip/tooltip.css ***!
  \**********************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck.ck-balloon-panel.ck-tooltip {\\n| \\t/* Keep tooltips transparent for any interactions. */\\n| \\tpointer-events: none;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/components/tooltip/tooltip.css?");

/***/ }),

/***/ 1079:
/*!***********************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-ui/theme/globals/globals.css ***!
  \***********************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected character '@' (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> @import \\\"./_hidden.css\\\";\\n| @import \\\"./_reset.css\\\";\\n| @import \\\"./_zindex.css\\\";\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-ui/theme/globals/globals.css?");

/***/ }),

/***/ 1169:
/*!******************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-widget/theme/widget.css ***!
  \******************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> :root {\\n| \\t--ck-color-resizer: var(--ck-color-focus-border);\\n| \\t--ck-color-resizer-tooltip-background: hsl(0, 0%, 15%);\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-widget/theme/widget.css?");

/***/ }),

/***/ 1650:
/*!************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-widget/theme/widgetresize.css ***!
  \************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck .ck-widget_with-resizer {\\n| \\t/* Make the widget wrapper a relative positioning container for the drag handle. */\\n| \\tposition: relative;\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-widget/theme/widgetresize.css?");

/***/ }),

/***/ 1167:
/*!****************************************************************************!*\
  !*** ./node_modules/@ckeditor/ckeditor5-widget/theme/widgettypearound.css ***!
  \****************************************************************************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (6:0)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n|  */\\n| \\n> .ck .ck-widget {\\n| \\t/*\\n| \\t * Styles of the type around buttons\");\n\n//# sourceURL=webpack://trudesk/./node_modules/@ckeditor/ckeditor5-widget/theme/widgettypearound.css?");

/***/ })

}]);